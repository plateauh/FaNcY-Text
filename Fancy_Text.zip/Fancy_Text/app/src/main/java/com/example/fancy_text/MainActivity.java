package com.example.fancy_text;

import androidx.appcompat.app.AppCompatActivity;

import android.content.ContentProviderClient;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.CheckBox;
import android.widget.EditText;
import android.widget.TextView;

public class MainActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);


        EditText editText = findViewById(R.id.editText);
        TextView textView = findViewById(R.id.textView);
        CheckBox checkBox = findViewById(R.id.checkBox);

        Button button = findViewById(R.id.button);
        button.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                String userInput = editText.getText().toString();
                String output = "";
                if (checkBox.isChecked())
                    output = convertTextIgnored(userInput);
                else {
                    output = convertText(userInput);
                }
                textView.setText(output);
            }
        });

    }

    public String convertTextIgnored(String input){
        String output = "";
        char letter = ' ';
        int counter = 0;
        for (int i=0; i<input.length(); i++){
            if (!Character.isLetterOrDigit(input.charAt(i))){
                letter = input.charAt(i);
            }
            else if (counter % 2 == 0){
                letter = Character.toUpperCase(input.charAt(i));
                counter++;
            }
            else {
                letter = Character.toLowerCase(input.charAt(i));
                counter++;
            }
            output += letter;

        }
        return output;
    }

    public String convertText(String input){
        String output = "";
        char letter = ' ';
        for (int i=0; i<input.length(); i++){
            if (i % 2 == 0){
                letter = Character.toUpperCase(input.charAt(i));
            }
            else {
                letter = Character.toLowerCase(input.charAt(i));
            }
            output += letter;
        }
        return output;
    }
}